

<?php $__env->startSection('content'); ?>
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight"><?php echo e($pageHeading); ?></h1>
                        </div>
                        <!-- Actions -->
                        <div class="col-sm-6 col-12 text-sm-end">
                            <div class="mx-n1">
                                
                                <a href="<?php echo e(route('new.contest')); ?>" class="btn d-inline-flex btn-sm btn-primary mx-1">
                                    <span class=" pe-2">
                                        <i class="bi bi-plus"></i>
                                    </span>
                                    <span>Create</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Nav -->
                    <ul class="nav nav-tabs mt-4 overflow-x border-0">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.questions')); ?>" class="nav-link active">All</a>
                        </li>
                        <li class="nav-item ">
                            <a href="#" class="nav-link font-regular">Live Contest</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link font-regular">Time Limit Contest</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link font-regular">Any Time</a>
                        </li>
                    </ul>
                </div>
            </div>
        </header>
        <!-- Main -->
        <main class="py-6 bg-surface-secondary">
            
            <div class="continer-fluid my-2 px-5">
                <div class="row">
                    <div class="col-12">
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php elseif(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php elseif(Session::has('warning')): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('warning')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


            <div class="container-fluid">
                <!-- Card stats -->
                <div class="row g-6 mb-6">
                    <div class="col-xl-3 col-sm-6 col-12">
                        <div class="card shadow border-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class="h6 font-semibold text-muted text-sm d-block mb-2">All Contest</span>
                                        <span class="h3 font-bold mb-0"><?php echo e($allContestCount); ?></span>
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-tertiary text-white text-lg rounded-circle">
                                            <i class="bi bi-credit-card"></i>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="card shadow border-0 mb-7">
                    <div class="card-header">
                        <h5 class="mb-0">List</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-nowrap">
                            <thead class="thead-light">
                                <tr>

                                    <th scope="col">Sno</th>
                                    <th scope="col">Contest Name</th>
                                    <th scope="col">Date Time</th>
                                    <th scope="col">Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sno=1;?>
                                <?php $__currentLoopData = $allContest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sno++); ?></td>
                                       
                                        <td>
                                            <?php
                                                $category = $contest->contest_id;
                                                if (isset($categoriesMap[$category])) {
                                                        echo '<span class="rounded-pill px-2 py-1 border border-1 me-1">' . $categoriesMap[$category] . '</span>';
                                                    } else {
                                                        echo '<span class="rounded-pill px-2 py-1 border border-1 me-1">Others</span>';
                                                    }
                                            ?>
                                        </td>
                                        <td class="">
                                            <?php echo e(date("d M Y h:i A", strtotime($contest->start_time))); ?>

                                        </td>
                                        <td>
                                            <?php
                                                if ($contest->status == 0) {
                                                    echo '<b>Inactive</b>';
                                                } else {
                                                    echo "<span class='text-success'><b>Active</b></span>";
                                                }
                                            ?>
                                        </td>


                                        <td class="">
                                            <a href="<?php echo e(route('admin.view.contest',['id'=>$contest->id])); ?>" class="btn btn-sm btn-primary"><i class="bi bi-eye"></i> View</a>
                                            <a href="<?php echo e(route('admin.edit.contest',['id'=>$contest->id])); ?>" class="btn d-inline-flex btn-sm  btn-neutral mx-1">
                                                <span class=" pe-2">
                                                    <i class="bi bi-pen"></i>
                                                </span>
                                                <span>Edit</span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                        <?php echo e($allContest->links()); ?>

                    </div>
                    <div class="card-footer border-0 py-5">
                        <span class="text-muted text-sm">Showing <?php echo e($allContestCount > 10 ? 10 : $allContestCount); ?>

                            items out
                            of <?php echo e($allContestCount); ?> results
                            found</span>
                    </div>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizmania\admin_panel\resources\views/contests.blade.php ENDPATH**/ ?>