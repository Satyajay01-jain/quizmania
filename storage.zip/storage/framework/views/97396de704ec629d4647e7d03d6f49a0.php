

<?php $__env->startSection('content'); ?>
    <?php
        // default values
        $title_type = 'text';
        $option_type = 'text';
    ?>
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center mb-4">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight"><?php echo e($pageHeading); ?></h1>
                        </div>
                        <!-- Actions -->
                        <div class="col-sm-6 col-12 text-sm-end">
                            <div class="mx-n1">
                                <button onclick="history.back()"
                                    class="btn d-inline-flex btn-sm btn-neutral border-base mx-1">
                                    <span class=" pe-2">
                                        <i class="bi bi-arrow-bar-left"></i>
                                    </span>
                                    <span>Go Back</span>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- Main -->
        <main class="py-6 bg-surface-secondary">
            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php elseif(Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php elseif(Session::has('warning')): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('warning')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="container-fluid">

                <div class="card shadow border-0 mb-7">
                    <div class="card-header">
                        <h5 class="mb-0">Enter Details</h5>
                    </div>
                    <div class="py-2 px-4">
                        <form class="" method="post" action="<?php echo e(route('post_new_question')); ?>" enctype="multipart/form-data" onsubmit="return submitForm()">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="mb-3">
                                        <label for="title_type" class="form-label">Title Type <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select <?php $__errorArgs = ['title_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title_type" onchange="setTitle(this)">
                                            <option value="text">Text</option>
                                            <option value="image">Image (.png,.jpg,.jpeg)</option>
                                            <option value="youtubevideolink">Video (youtube video link)</option>
                                            <option value="video">Video (.mp4 file)</option>
                                        </select>
                                        
                                        <?php $__errorArgs = ['title_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-sm-6">
                                    <div class="mb-3">
                                        <label class="form-label">Enter Title <span class="text-danger">*</span></label>
                                        <div class="mt-1" id="titleDiv">
                                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" required placeholder="Question title here...">
                                        </div>
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            

                           

                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="mb-3">
                                        <label for="option_type" class="form-label">Select option type <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" name="option_type" id="option_type" onchange="setOptions()">
                                            <option value="text">Text</option>
                                            <option value="image">Image (.png,.jpg,.jpeg)</option>
                                            <option value="youtubevideolink">Video (youtube video link)</option>
                                            <option value="video">Video (.mp4 file)</option>
                                        </select>
        
                                        <?php $__errorArgs = ['option_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="mb-3">
                                        <label for="option_count" class="form-label">Option count <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" name="option_count" id="option_count" onchange="setOptions()">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                        <?php $__errorArgs = ['option_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Enter options <span class="text-danger">*</span></label>
                                <div class="mt-1" id="optionsDiv">
                                    <input type="text" class="form-control" name="option[]" placeholder="Question options here..." required>
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                <div class="mb-3">
                                    <label class="form-label">Correct Option No. <span class="text-danger">*</span></label>
                                    <div class="mt-1" id="correctOptionDiv">
                                        <div class="form-check form-check-inline">
                                            <input type="checkbox" class="form-check-input" id="o1"  value="1" name="correct_option[]">
                                            <label class="form-check-label" for="correct_option">Option 1</label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['correct_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="mb-3">
                                <label for="question_category" class="form-label">Question Category </label>
                                        <br>
                                <div class="form-check form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="question_category" value="1" name="question_category[]">
                                    <label class="form-check-label" for="question_category">Live Contest</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="question_category2" value="2" name="question_category[]">
                                    <label class="form-check-label" for="question_category2">Time Limit Contest</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="question_category3" value="3" name="question_category[]">
                                    <label class="form-check-label" for="question_category3">Any Time Contest</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="question_category4" value="4" name="question_category[]">
                                    <label class="form-check-label" for="question_category4">Question Bank</label>
                                </div>

                                
                            </div>

                            <div class="mb-3">
                                <label for="status" class="form-label">Status <span
                                        class="text-danger">*</span></label>

                                <select class="form-select" name="status" id="status">
                                    <option  value="1">Active</option>
                                    <option  value="0">Inactive</option>
                                </select>

                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <br>
                            <button type="submit" class="btn btn-primary" id="submit_btn">Submit</button>
                        </form>
                    </div>
                    <div class="card-footer border-0 py-5">
                        <span class=" text-danger text-sm">* Allowed file type - .png,.jpg,.jpeg,.mp4 and max size is 5 mb.</span>
                    </div>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
        function setTitle(e){
            let titleType=e.value;
            let titleDiv=document.getElementById("titleDiv");
            if(titleType=="text"){
                titleDiv.innerHTML = '';
                let textInput=document.createElement('input');
                textInput.name="title";
                textInput.type="text";
                textInput.placeholder="Question title here...";
                textInput.className="form-control";
                textInput.setAttribute("required","");
                titleDiv.appendChild(textInput);
                console.log(titleType);
            }
            else if(titleType=="image"){
                titleDiv.innerHTML = '';
                let textInput=document.createElement('input');
                textInput.name="title";
                textInput.type="file";
                textInput.className="form-control";
                textInput.setAttribute("required","");
                textInput.setAttribute("accept",".png,.jpg,.jpeg");
                titleDiv.appendChild(textInput);
                console.log(titleType)
            }
            else if(titleType=="youtubevideolink"){
                titleDiv.innerHTML = '';
                let textInput=document.createElement('input');
                textInput.name="title";
                textInput.type="text";
                textInput.placeholder="Question Youtube link here...";
                textInput.className="form-control";
                textInput.setAttribute("required","");
                titleDiv.appendChild(textInput);
                console.log(titleType)
            }
            else{
                titleDiv.innerHTML = '';
                let textInput=document.createElement('input');
                textInput.name="title";
                textInput.type="file";
                textInput.className="form-control";
                textInput.setAttribute("required","");
                textInput.setAttribute("accept",".mp4");
                titleDiv.appendChild(textInput);
                console.log(titleType)
            }
        }

        function setOptions(){
            let optionType=document.getElementById("option_type").value;
            let optionCount=document.getElementById("option_count").value;
            let optionDiv=document.getElementById("optionsDiv");
            let correctOptionDiv=document.getElementById("correctOptionDiv");
            optionDiv.innerHTML = '';
            correctOptionDiv.innerHTML = '';
            i=1;
            while(i<=optionCount){

                if(optionType=="text"){
                    
                    let parentDiv=document.createElement('div');
                    parentDiv.className="mb-2";
                    let pTag=document.createElement('p');
                    pTag.innerText="Option "+i;
                    let textInput=document.createElement('input');
                    textInput.name="option[]";
                    textInput.type="text";
                    textInput.placeholder="Option here...";
                    textInput.className="form-control";
                    textInput.setAttribute("required","");
                    parentDiv.appendChild(pTag);
                    parentDiv.appendChild(textInput);
                    optionDiv.appendChild(parentDiv);
                    console.log(optionType);
                }
                else if(optionType=="image"){

                    let parentDiv=document.createElement('div');
                    parentDiv.className="mb-2";
                    let pTag=document.createElement('p');
                    pTag.innerText="Option "+i;
                    let textInput=document.createElement('input');
                    textInput.name="option[]";
                    textInput.type="file";
                    textInput.className="form-control";
                    textInput.setAttribute("required","");
                    textInput.setAttribute("accept",".png,.jpg,.jpeg");
                    parentDiv.appendChild(pTag);
                    parentDiv.appendChild(textInput);
                    optionDiv.appendChild(parentDiv);

                    console.log(optionType)
                }
                else if(optionType=="youtubevideolink"){
                    let parentDiv=document.createElement('div');
                    parentDiv.className="mb-2";
                    let pTag=document.createElement('p');
                    pTag.innerText="Option "+i;
                    let textInput=document.createElement('input');
                    textInput.name="option[]";
                    textInput.type="text";
                    textInput.placeholder="Option Youtube link here...";
                    textInput.className="form-control";
                    textInput.setAttribute("required","");
                    parentDiv.appendChild(pTag);
                    parentDiv.appendChild(textInput);
                    optionDiv.appendChild(parentDiv);
                }
                else{
                    let parentDiv=document.createElement('div');
                    parentDiv.className="mb-2";
                    let pTag=document.createElement('p');
                    pTag.innerText="Option "+i;
                    let textInput=document.createElement('input');
                    textInput.name="option[]";
                    textInput.type="file";
                    textInput.className="form-control";
                    textInput.setAttribute("required","");
                    textInput.setAttribute("accept",".mp4");
                    parentDiv.appendChild(pTag);
                    parentDiv.appendChild(textInput);
                    optionDiv.appendChild(parentDiv);
                    console.log(optionType)
                }


                // setting correction tab
                

                let parentDiv2=document.createElement('div');
                    parentDiv2.className="form-check form-check-inline";

                    let labelTag=document.createElement('label');
                    labelTag.className="form-check-label";
                    labelTag.setAttribute("for","o"+i);
                    labelTag.innerText="Option "+i;

                    let checkboxInput=document.createElement('input');
                    checkboxInput.name="correct_option[]";
                    checkboxInput.type="checkbox";
                    checkboxInput.value=i;
                    checkboxInput.id="o"+i;
                    checkboxInput.className="form-check-input";
                    parentDiv2.appendChild(checkboxInput);
                    parentDiv2.appendChild(labelTag);
                    correctOptionDiv.appendChild(parentDiv2);
                    i++;
            }
            
        }
        function submitForm(){
            let submit_btn=document.getElementById("submit_btn");
            submit_btn.disabled =true;
            submit_btn.innerText="Submiting...";
            return true;
        }
</script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\quizmania\admin_panel\resources\views/new_question.blade.php ENDPATH**/ ?>