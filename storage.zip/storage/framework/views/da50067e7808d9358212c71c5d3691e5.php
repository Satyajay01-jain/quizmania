<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quizmania - Knowledge Bank</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(url('/resources/css/common.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/@webpixels/css@1.1.5/dist/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.4.0/font/bootstrap-icons.min.css">

    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    
    <!-- Dashboard -->
    <div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
        <!-- Vertical Navbar -->
        <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg"
            id="navbarVertical">
            <div class="container-fluid">
                <!-- Toggler -->
                <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse"
                    data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Brand -->
                <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                    
                    <h3>Quizmania</h3>
                </a>
                <!-- User menu (mobile) -->
                <div class="navbar-user d-lg-none">
                    <!-- Dropdown -->
                    <div class="dropdown">
                        <!-- Toggle -->
                        <a href="#" id="sidebarAvatar" role="button" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <div class="avatar-parent-child">
                                <img alt="Image Placeholder"
                                    src="https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=3&w=256&h=256&q=80"
                                    class="avatar avatar- rounded-circle">
                                <span class="avatar-child avatar-badge bg-success"></span>
                            </div>
                        </a>
                        <!-- Menu -->
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="sidebarAvatar">
                            <a href="#" class="dropdown-item">Profile</a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="#" class="dropdown-item">Billing</a>
                            <hr class="dropdown-divider">
                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">Logout</a>
                        </div>
                    </div>
                </div>

                <!-- Collapse -->
                <div class="collapse navbar-collapse" id="sidebarCollapse">
                    <!-- Navigation -->
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="dashboard" ?'active':''?>" href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="bi bi-house"></i> Dashboard
                            </a>
                        </li>
                        <hr>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="questions" ?'active':''?>" href="<?php echo e(route('admin.questions')); ?>">
                                <i class="bi bi-bar-chart"></i> Questions
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="newquestion" ?'active':''?>" href="<?php echo e(route('new.question')); ?>">
                                <i class="bi bi-plus"></i> Questions
                            </a>
                        </li>

                        <hr>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="contests" ?'active':''?>" href="<?php echo e(route('admin.contests')); ?>">
                                <i class="bi bi-bar-chart"></i> Contests
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="newlivecontest" ?'active':''?>" href="<?php echo e(route('admin.new.live.contest')); ?>">
                                <i class="bi bi-plus"></i> Live Contest
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="newtimelimitcontest" ?'active':''?>" href="<?php echo e(route('admin.new.timelimit.contest')); ?>">
                                <i class="bi bi-plus"></i> Time Limit Contest
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $page=="newanytimecontest" ?'active':''?>" href="<?php echo e(route('admin.new.anytime.contest')); ?>">
                                <i class="bi bi-plus"></i> Any Time Contest
                            </a>
                        </li>

                        <hr>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="bi bi-people"></i> Users
                            </a>
                        </li>
                    </ul>
                    <!-- Divider -->
                    <hr class="navbar-divider my-5 opacity-20">
                    <!-- Navigation -->
                    
                    <!-- Push content down -->
                    <div class="mt-auto"></div>
                    <!-- User (md) -->
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="bi bi-person-square"></i> Account
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                                <i class="bi bi-box-arrow-left"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Main content -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>


<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\quizmania\admin_panel\resources\views/layouts/admin_layout.blade.php ENDPATH**/ ?>